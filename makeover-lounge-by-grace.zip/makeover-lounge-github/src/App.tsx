import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TrustBanner from './components/TrustBanner';
import Services from './components/Services';
import InstagramFeed from './components/InstagramFeed';
import Contact from './components/Contact';
import Footer from './components/Footer';
import MobileCTA from './components/MobileCTA';

function App() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground relative font-sans">
      <Navbar />
      <main>
        <Hero />
        <TrustBanner />
        <Services />
        <InstagramFeed />
        <Contact />
      </main>
      <Footer />
      <MobileCTA />
    </div>
  );
}

export default App;
