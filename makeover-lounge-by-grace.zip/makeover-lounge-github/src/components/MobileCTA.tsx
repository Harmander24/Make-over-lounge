import React from 'react';
import { Button } from '@/components/ui/button';
import { Phone } from 'lucide-react';

export default function MobileCTA() {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-md border-t border-white/10 z-50 animate-in slide-in-from-bottom-full duration-500">
      <Button 
        className="w-full bg-primary text-primary-foreground font-serif font-bold text-lg py-6 uppercase tracking-widest shadow-[0_0_20px_rgba(204,153,51,0.3)] rounded-none"
        onClick={() => window.location.href = 'tel:08288800139'}
      >
        <Phone className="w-5 h-5 mr-2" />
        Book Now — Call
      </Button>
    </div>
  );
}
