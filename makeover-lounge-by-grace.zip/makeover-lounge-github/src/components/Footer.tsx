import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-background py-16 border-t border-white/5 text-center">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-serif font-bold tracking-wider text-primary mb-2">
          GRACE
        </h2>
        <p className="text-sm font-sans tracking-widest text-foreground/60 uppercase mb-8">
          Makeover Lounge
        </p>
        
        <div className="flex justify-center gap-6 mb-12 text-sm font-sans tracking-widest text-foreground/80 uppercase">
          <a href="#services" className="hover:text-primary transition-colors">Services</a>
          <a href="#gallery" className="hover:text-primary transition-colors">Gallery</a>
          <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
        </div>

        <p className="text-foreground/40 text-sm">
          &copy; {new Date().getFullYear()} Makeover Lounge by GRACE. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
