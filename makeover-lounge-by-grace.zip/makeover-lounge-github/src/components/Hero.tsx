import React from 'react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function Hero() {
  const handleScroll = (href: string) => {
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[100dvh] flex items-center justify-center pt-24 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/40 to-background z-10" />
        <img 
          src="/hero-bg.png" 
          alt="Luxury Salon Interior" 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container relative z-10 mx-auto px-6 md:px-12 text-center max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <span className="text-primary font-sans font-semibold tracking-[0.2em] uppercase text-sm md:text-base mb-6 block">
            Welcome to Civil Lines
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-foreground leading-tight mb-8 drop-shadow-lg">
            Transform Your Look, <br/>
            <span className="italic font-light text-primary">Elevate Your Confidence.</span>
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 font-light max-w-2xl mx-auto mb-12 drop-shadow-md">
            Ludhiana's premier destination for luxury hair, skin, nails & bridal artistry. Experience the pinnacle of personalized beauty.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-serif font-bold text-lg px-10 py-7 uppercase tracking-widest w-full sm:w-auto transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(204,153,51,0.5)]"
              onClick={() => handleScroll('#contact')}
            >
              Book Appointment
            </Button>
            <Button 
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-serif font-bold text-lg px-10 py-7 uppercase tracking-widest w-full sm:w-auto transition-all duration-300 bg-transparent backdrop-blur-sm"
              onClick={() => handleScroll('#services')}
            >
              Explore Services
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="w-[1px] h-16 bg-gradient-to-b from-primary to-transparent" />
      </motion.div>
    </section>
  );
}
