import React from 'react';
import { Star } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TrustBanner() {
  return (
    <section className="bg-foreground text-background py-10 md:py-16 border-y border-primary/20">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-center gap-6 text-center">
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
            >
              <Star className="w-6 h-6 md:w-8 md:h-8 fill-primary text-primary" />
            </motion.div>
          ))}
        </div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <h2 className="text-xl md:text-2xl font-serif font-medium tracking-wide uppercase">
            565+ Five-Star Reviews <span className="opacity-50 mx-2 hidden md:inline">|</span> <span className="block md:inline mt-2 md:mt-0 text-primary">Trusted by Ludhiana's Finest</span>
          </h2>
        </motion.div>
      </div>
    </section>
  );
}
