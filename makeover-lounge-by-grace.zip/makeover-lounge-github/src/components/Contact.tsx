import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Contact() {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Request Sent Successfully",
      description: "Our concierge will contact you shortly to confirm your appointment.",
    });
    (e.target as HTMLFormElement).reset();
  };

  return (
    <section id="contact" className="py-24 md:py-32 bg-background border-t border-white/5">
      <div className="container mx-auto px-6 md:px-12 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          
          {/* Info Side */}
          <div>
            <span className="text-primary font-sans font-semibold tracking-[0.2em] uppercase text-sm block mb-4">
              Visit Us
            </span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-10">
              The Sanctuary of Beauty
            </h2>

            <div className="space-y-8 mb-12">
              <div className="flex gap-4">
                <MapPin className="w-6 h-6 text-primary shrink-0" />
                <div>
                  <h4 className="font-serif font-bold text-lg mb-1">Civil Lines, Ludhiana</h4>
                  <p className="text-foreground/70 font-light leading-relaxed">
                    Rani Jhansi Rd, Civil Lines<br/>
                    Ludhiana, Punjab 141001
                  </p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <Phone className="w-6 h-6 text-primary shrink-0" />
                <div>
                  <h4 className="font-serif font-bold text-lg mb-1">Direct Line</h4>
                  <p className="text-foreground/70 font-light">
                    082888 00139
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <Clock className="w-6 h-6 text-primary shrink-0" />
                <div>
                  <h4 className="font-serif font-bold text-lg mb-1">Hours</h4>
                  <p className="text-foreground/70 font-light">
                    Mon - Sun: 10:00 AM - 8:00 PM
                  </p>
                </div>
              </div>
            </div>

            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-serif font-bold text-lg px-10 py-7 uppercase tracking-widest w-full sm:w-auto"
              onClick={() => window.location.href = 'tel:08288800139'}
            >
              Call Now: 08288800139
            </Button>
          </div>

          {/* Form Side */}
          <div className="bg-secondary/40 p-8 md:p-12 border border-white/5 relative">
            <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 blur-3xl rounded-full" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-primary/5 blur-3xl rounded-full" />
            
            <h3 className="text-2xl font-serif font-bold mb-8 relative z-10">Request an Appointment</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
              <div>
                <Input 
                  placeholder="Your Full Name" 
                  required 
                  className="bg-background border-white/10 text-foreground h-14 rounded-none focus-visible:ring-primary focus-visible:border-primary placeholder:text-foreground/40"
                />
              </div>
              <div>
                <Input 
                  type="tel" 
                  placeholder="Phone Number" 
                  required 
                  className="bg-background border-white/10 text-foreground h-14 rounded-none focus-visible:ring-primary focus-visible:border-primary placeholder:text-foreground/40"
                />
              </div>
              <div>
                <select 
                  required
                  className="w-full bg-background border border-white/10 text-foreground h-14 rounded-none focus-visible:ring-primary focus-visible:border-primary px-3 opacity-90"
                >
                  <option value="" disabled selected className="text-foreground/40">Select Service of Interest</option>
                  <option value="hair">Hair Artistry</option>
                  <option value="skin">Skin Aesthetics</option>
                  <option value="nails">Nail Studio</option>
                  <option value="bridal">Bridal Couture</option>
                  <option value="other">Other / Consultation</option>
                </select>
              </div>
              <div>
                <Textarea 
                  placeholder="Message or specific requests..." 
                  className="bg-background border-white/10 text-foreground min-h-[120px] rounded-none focus-visible:ring-primary focus-visible:border-primary placeholder:text-foreground/40 resize-none"
                />
              </div>
              <Button type="submit" className="w-full bg-foreground text-background hover:bg-primary hover:text-primary-foreground font-serif font-bold py-6 uppercase tracking-widest transition-colors duration-300 rounded-none">
                Send Request
              </Button>
            </form>
          </div>

        </div>

        {/* Map placeholder */}
        <div className="mt-24 h-[400px] w-full bg-secondary relative overflow-hidden group">
          <div className="absolute inset-0 bg-background/20 group-hover:bg-transparent transition-colors z-10 pointer-events-none" />
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3423.639535567364!2d75.832717!3d30.9107!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a8374a2df8ab9%3A0xb366b5952f20dc00!2sRani%20Jhansi%20Rd%2C%20Civil%20Lines%2C%20Ludhiana%2C%20Punjab%20141001!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
            width="100%" 
            height="100%" 
            style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) grayscale(100%)' }} 
            allowFullScreen 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            className="opacity-80 mix-blend-luminosity"
          ></iframe>
        </div>
      </div>
    </section>
  );
}
