import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const services = [
  {
    id: 'hair',
    title: 'Hair Artistry',
    examples: ['Balayage & Highlights', 'Keratin & Botox', 'Precision Cutting'],
    image: '/service-hair.png'
  },
  {
    id: 'skin',
    title: 'Skin Aesthetics',
    examples: ['HydraFacial', 'Advanced Peels', 'Bridal Glow Treatments'],
    image: '/service-skin.png'
  },
  {
    id: 'nails',
    title: 'Nail Studio',
    examples: ['Gel Extensions', 'Intricate Nail Art', 'Luxury Manicure'],
    image: '/service-nails.png'
  },
  {
    id: 'bridal',
    title: 'Bridal Couture',
    examples: ['HD Bridal Makeup', 'Pre-Bridal Packages', 'Draping & Styling'],
    image: '/service-bridal.png'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-6 md:px-12">
        <div className="mb-16 md:mb-24">
          <span className="text-primary font-sans font-semibold tracking-[0.2em] uppercase text-sm block mb-4">
            Our Expertise
          </span>
          <h2 className="text-4xl md:text-6xl font-serif font-bold text-foreground">
            Curated Services
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: index * 0.15 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[3/4] overflow-hidden mb-6 bg-secondary/50">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-90 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-60" />
              </div>
              
              <h3 className="text-2xl font-serif font-bold text-foreground mb-4 group-hover:text-primary transition-colors">
                {service.title}
              </h3>
              
              <ul className="space-y-2 mb-6">
                {service.examples.map((example, i) => (
                  <li key={i} className="text-foreground/70 font-light text-sm tracking-wide">
                    — {example}
                  </li>
                ))}
              </ul>
              
              <div className="inline-flex items-center gap-2 text-primary font-serif font-bold uppercase tracking-widest text-sm group-hover:gap-4 transition-all">
                <span>View Details</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
