import React from 'react';
import { Button } from '@/components/ui/button';
import { Instagram } from 'lucide-react';
import { motion } from 'framer-motion';

export default function InstagramFeed() {
  const images = [
    '/ig-1.png', '/ig-2.png', '/ig-3.png', 
    '/ig-4.png', '/ig-5.png', '/ig-6.png'
  ];

  return (
    <section id="gallery" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-6 md:px-12 text-center">
        <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
          Follow Our Work
        </h2>
        <a href="https://instagram.com/gracesalons" target="_blank" rel="noreferrer" className="text-primary font-sans tracking-widest uppercase mb-16 inline-block hover:underline underline-offset-8">
          @gracesalons
        </a>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-4 mb-16 max-w-6xl mx-auto">
          {images.map((src, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="aspect-square overflow-hidden relative group"
            >
              <img 
                src={src} 
                alt={`Instagram feed ${i+1}`} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-background/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <Instagram className="w-8 h-8 text-primary" />
              </div>
            </motion.div>
          ))}
        </div>

        <Button 
          variant="outline"
          className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-serif font-bold px-8 py-6 uppercase tracking-widest"
        >
          <Instagram className="w-5 h-5 mr-3" />
          Follow on Instagram
        </Button>
      </div>
    </section>
  );
}
